import type { AddressInfo } from "node:net";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { Server } from "node:http";
import type { PrismaClient } from "../generated/prisma/client.js";
import {
  PublicAccessLinkService,
  type PublicAccessLinkRecord,
  type PublicAccessLinkStore,
} from "../access-links/public-page.js";
import { signAccessLink } from "../access-links/token.js";
import { createApp } from "./app.js";
import {
  PublicPortalAccessService,
  type PublicPortalAccessGrant,
  type PublicPortalAccessStore,
} from "../portal-access/public.js";
import { signPortalGrantToken } from "../portal-access/token.js";
import { CommunicationScenario } from "../generated/prisma/enums.js";
import {
  PublicUnsubscribeService,
  type PublicUnsubscribeStore,
} from "../communication-unsubscribe/public.js";
import { signUnsubscribeToken, type UnsubscribeTokenPayload } from "../communication-unsubscribe/token.js";
import {
  decodePortalCaseCursor,
  encodePortalCaseCursor,
  type HospitalPortalViewModel,
  type PortalCaseListItem,
  type PortalDeviceDetail,
  type PortalDocument,
} from "../portal-access/view-model.js";
import type { PortalAuthorizationContext } from "../portal-access/public.js";
import type { PublicFileService } from "../assets/public-files.js";
import type { PortalAnalyticsInput, PortalAnalyticsWriter } from "../analytics/service.js";

const secret = "test-access-link-signing-secret-with-at-least-32-bytes";
let server: Server | null = null;

afterEach(async () => {
  if (!server) return;
  await new Promise<void>((resolve, reject) =>
    server?.close((error) => error ? reject(error) : resolve()));
  server = null;
});

describe("public API", () => {
  it("records a mail link click for a valid portal grant without creating a confirmed view", async () => {
    const grant = portalRecord();
    const analytics = new MemoryAnalytics();
    const { baseUrl } = await startApp(new MemoryStore(null), grant,
      new MemoryUnsubscribeStore(null), async () => emptyPortalView(), { analytics });
    const token = signPortalGrantToken(grant, secret);
    expect((await fetch(`${baseUrl}/d/${token}`)).status).toBe(200);
    expect(analytics.linkClicks).toEqual([expect.objectContaining({
      portalAccessGrantId: "portalGrantId", communicationDeliveryId: "deliveryId",
      sourceHospitalRecordId: "recHospital",
    })]);
    expect(analytics.events).toEqual([]);
  });

  it("accepts only a separate validated JS analytics request for a real portal view", async () => {
    const grant = portalRecord();
    const analytics = new MemoryAnalytics();
    const { baseUrl } = await startApp(new MemoryStore(null), grant,
      new MemoryUnsubscribeStore(null), async () => emptyPortalView(), { analytics });
    const token = signPortalGrantToken(grant, secret);
    const response = await fetch(`${baseUrl}/api/portal/${token}/analytics`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ eventType: "PORTAL_VIEW_CONFIRMED",
        sessionId: "123e4567-e89b-42d3-a456-426614174000" }),
    });
    expect(response.status).toBe(204);
    expect(analytics.events).toEqual([expect.objectContaining({ input: {
      eventType: "PORTAL_VIEW_CONFIRMED",
      sessionId: "123e4567-e89b-42d3-a456-426614174000",
    } })]);
  });

  it("does not write analytics for invalid tokens or client-supplied identity fields", async () => {
    const analytics = new MemoryAnalytics();
    const grant = portalRecord();
    const { baseUrl } = await startApp(new MemoryStore(null), grant,
      new MemoryUnsubscribeStore(null), async () => emptyPortalView(), { analytics });
    const invalid = await fetch(`${baseUrl}/api/portal/invalid/analytics`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ eventType: "SCREEN_VIEW", screen: "inspections",
        sessionId: "123e4567-e89b-42d3-a456-426614174000" }),
    });
    expect(invalid.status).toBe(404);
    const token = signPortalGrantToken(grant, secret);
    const spoofed = await fetch(`${baseUrl}/api/portal/${token}/analytics`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ eventType: "SCREEN_VIEW", screen: "inspections",
        sessionId: "123e4567-e89b-42d3-a456-426614174000", hospitalId: "other" }),
    });
    expect(spoofed.status).toBe(400);
    expect(analytics.events).toEqual([]);
  });

  it("protects the dashboard and defaults its API filter to PRODUCTION", async () => {
    const summary = vi.fn().mockResolvedValue({ ok: true });
    const admin = { summary, hospitals: vi.fn(), hospital: vi.fn(),
      deliveries: vi.fn(), activity: vi.fn() };
    const { baseUrl } = await startApp(new MemoryStore(null), null,
      new MemoryUnsubscribeStore(null), async () => emptyPortalView(), {
        analyticsAdmin: admin, analyticsAuth: { enabled: true, user: "ops", password: "secret" },
      });
    expect((await fetch(`${baseUrl}/ops/analytics`)).status).toBe(401);
    const authorization = `Basic ${Buffer.from("ops:secret").toString("base64")}`;
    const response = await fetch(`${baseUrl}/api/ops/analytics/summary`, {
      headers: { authorization },
    });
    expect(response.status).toBe(200);
    expect(summary).toHaveBeenCalledWith(expect.objectContaining({ mode: "PRODUCTION" }));
    expect(response.headers.get("cache-control")).toBe("no-store");
  });

  it("keeps /health independent from Airtable configuration", async () => {
    const { baseUrl } = await startApp(new MemoryStore(null));
    const response = await fetch(`${baseUrl}/health`);
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ status: "ok" });
  });

  it("serves /d/:token publicly with privacy and indexing headers", async () => {
    const record = accessRecord();
    const { baseUrl } = await startApp(new MemoryStore(record));
    const token = signAccessLink(record, secret);
    const response = await fetch(`${baseUrl}/d/${token}`);
    const html = await response.text();

    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toBe("no-store");
    expect(response.headers.get("x-robots-tag")).toBe(
      "noindex, nofollow, noarchive",
    );
    expect(response.headers.get("referrer-policy")).toBe("no-referrer");
    expect(response.headers.get("content-security-policy")).toContain(
      "default-src 'none'",
    );
    expect(html).toContain('<meta name="robots" content="noindex,nofollow,noarchive">');
  });

  it("serves a valid /p/:token with public-route security headers", async () => {
    const grant = portalRecord();
    const { baseUrl } = await startApp(new MemoryStore(null), grant);
    const response = await fetch(`${baseUrl}/p/${signPortalGrantToken(grant, secret)}`);
    const html = await response.text();
    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toBe("no-store");
    expect(response.headers.get("x-robots-tag")).toBe(
      "noindex, nofollow, noarchive",
    );
    expect(response.headers.get("referrer-policy")).toBe("no-referrer");
    expect(response.headers.get("content-security-policy")).toContain(
      "default-src 'none'",
    );
    expect(html).toContain("sessionStorage.getItem('emmaAnalyticsSessionId')");
    expect(html).toContain("sendAnalytics('UPGRADE_CLICK')");
    expect(html).toContain("navigator.sendBeacon");
  });

  it("serves a new context-scoped portal from /d/:token", async () => {
    const grant = portalRecord();
    const { baseUrl } = await startApp(new MemoryStore(null), grant);
    const response = await fetch(`${baseUrl}/d/${signPortalGrantToken(grant, secret)}`);
    expect(response.status).toBe(200);
    expect(response.headers.get("content-security-policy")).toContain("script-src 'nonce-");
    expect(await response.text()).toContain("portal szpitala");
  });

  it("redirects expired portal tokens to /link-expired", async () => {
    const grant = portalRecord({ expiresAt: new Date(Date.now() - 1) });
    const analytics = new MemoryAnalytics();
    const { baseUrl } = await startApp(new MemoryStore(null), grant,
      new MemoryUnsubscribeStore(null), async () => emptyPortalView(), { analytics });
    const response = await fetch(
      `${baseUrl}/p/${signPortalGrantToken(grant, secret)}`,
      { redirect: "manual" },
    );
    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe("/link-expired");
    const expiredPage = await fetch(`${baseUrl}/link-expired`);
    expect(expiredPage.status).toBe(200);
    expect(await expiredPage.text()).toContain("Ten link wygasł");
    expect(analytics.linkClicks).toEqual([]);
    expect(analytics.events).toEqual([]);
  });

  it("keeps the analytics dashboard fail-closed when admin ENV is absent", async () => {
    const { baseUrl } = await startApp(new MemoryStore(null));
    expect((await fetch(`${baseUrl}/ops/analytics`)).status).toBe(404);
    expect((await fetch(`${baseUrl}/api/ops/analytics/summary`)).status).toBe(404);
  });

  it("returns 404 for an invalid portal token", async () => {
    const { baseUrl } = await startApp(new MemoryStore(null), portalRecord());
    const response = await fetch(`${baseUrl}/p/invalid`);
    expect(response.status).toBe(404);
  });

  it("redirects an authorized asset to a short-lived signed storage URL", async () => {
    const grant = portalRecord();
    const signedUrl = vi.fn().mockResolvedValue("https://storage.invalid/signed");
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(), { publicFiles: { signedUrl } },
    );
    const response = await fetch(
      `${baseUrl}/p/${signPortalGrantToken(grant, secret)}/files/asset-1?variant=thumb`,
      { redirect: "manual" },
    );
    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe("https://storage.invalid/signed");
    expect(response.headers.get("cache-control")).toBe("no-store");
    expect(signedUrl).toHaveBeenCalledWith(
      expect.objectContaining({
        communicationDeliveryId: "deliveryId",
        sourceHospitalRecordId: "recHospital",
      }),
      "asset-1",
      "thumb",
    );
  });

  it("does not resolve a file for an invalid portal token", async () => {
    const signedUrl = vi.fn();
    const { baseUrl } = await startApp(
      new MemoryStore(null), portalRecord(), new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(), { publicFiles: { signedUrl } },
    );
    const response = await fetch(`${baseUrl}/p/invalid/files/asset-1?variant=portal`);
    expect(response.status).toBe(404);
    expect(signedUrl).not.toHaveBeenCalled();
  });

  it("does not resolve a file for an expired portal grant", async () => {
    const grant = portalRecord({ expiresAt: new Date(Date.now() - 1) });
    const signedUrl = vi.fn();
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(), { publicFiles: { signedUrl } },
    );
    const response = await fetch(
      `${baseUrl}/p/${signPortalGrantToken(grant, secret)}/files/asset-1?variant=portal`,
    );
    expect(response.status).toBe(404);
    expect(signedUrl).not.toHaveBeenCalled();
  });

  it("logs a safe structured reason when an authorized file request is denied", async () => {
    const grant = portalRecord();
    const log = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    const publicFiles: PublicFileService = {
      signedUrl: async () => null,
      resolve: async () => ({ url: null, reason: "NOT_EXPOSED" }),
    };
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(), { publicFiles },
    );
    const token = signPortalGrantToken(grant, secret);
    const response = await fetch(`${baseUrl}/p/${token}/files/asset-1?variant=document`);
    expect(response.status).toBe(404);
    expect(log).toHaveBeenCalledWith(
      "PORTAL_FILE_REQUEST_DENIED hasAssetId=true variant=document reason=NOT_EXPOSED status=404",
    );
    expect(log.mock.calls.flat().join(" ")).not.toContain(token);
    log.mockRestore();
  });

  it("does not let query parameters change portal hospital scope", async () => {
    const grant = portalRecord({ sourceHospitalRecordId: "hospital-A" });
    let authorization: PortalAuthorizationContext | null = null;
    const { baseUrl } = await startApp(
      new MemoryStore(null),
      grant,
      new MemoryUnsubscribeStore(null),
      async (value) => {
        authorization = value;
        return emptyPortalView();
      },
    );
    const response = await fetch(
      `${baseUrl}/p/${signPortalGrantToken(grant, secret)}?hospitalId=hospital-B`,
    );
    expect(response.status).toBe(200);
    expect(authorization?.sourceHospitalRecordId).toBe("hospital-A");
  });

  it("keeps paginated search and detail endpoints inside grant scope", async () => {
    const grant = portalRecord({ sourceHospitalRecordId: "hospital-A" });
    const scopes: string[] = [];
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(),
      {
        listCases: async (authorization) => {
          scopes.push(authorization.sourceHospitalRecordId);
          return { items: [], nextCursor: null };
        },
        getCase: async (authorization) => {
          scopes.push(authorization.sourceHospitalRecordId);
          return null;
        },
        getDevice: async (authorization) => {
          scopes.push(authorization.sourceHospitalRecordId);
          return null;
        },
      },
    );
    const token = signPortalGrantToken(grant, secret);
    const page = await fetch(`${baseUrl}/p/${token}/data/cases?q=secret&hospitalId=hospital-B`);
    expect(page.status).toBe(200);
    expect(await page.json()).toEqual({ items: [], nextCursor: null });
    expect((await fetch(`${baseUrl}/p/${token}/data/cases/case-B`)).status).toBe(404);
    expect((await fetch(`${baseUrl}/p/${token}/data/devices/device-B`)).status).toBe(404);
    expect(scopes).toEqual(["hospital-A", "hospital-A", "hospital-A"]);
  });

  it("serves Documents through the grant-scoped data endpoint and preserves server-side search", async () => {
    const grant = portalRecord({ sourceHospitalRecordId: "hospital-A" });
    const calls: Array<{ hospital: string; query?: string }> = [];
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(),
      { listDocuments: async (authorization, options) => {
        calls.push({ hospital: authorization.sourceHospitalRecordId, query: options.query });
        return { items: [], nextCursor: null };
      } },
    );
    const token = signPortalGrantToken(grant, secret);
    const response = await fetch(`${baseUrl}/p/${token}/data/documents?q=protokol&hospitalId=hospital-B`);
    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ items: [], nextCursor: null });
    expect(calls).toEqual([{ hospital: "hospital-A", query: "protokol" }]);
  });

  it("keeps the public sourceRecordId contract from Device detail to Case detail", async () => {
    const grant = portalRecord({
      sourceHospitalRecordId: "hospital-H1",
      entryContext: {
        type: "SERVICE_ORDER", sourceRecordId: "entry-repair",
        scenario: CommunicationScenario.REPAIR_RECEIVED,
      },
    });
    const item = portalCase("history-repair", "24676");
    const device: PortalDeviceDetail = {
      sourceRecordId: "device-H1", deviceName: "Device", manufacturer: null,
      model: null, serialNumber: null, inventoryNumber: null,
      currentStatus: "Aktywne", validUntil: null, inspectionPerformedAt: null,
      inspectionResult: null, cases: { items: [item], nextCursor: null }, lockedCaseCount: 0,
    };
    const requestedCaseIds: string[] = [];
    const requestedHospitalIds: string[] = [];
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(),
      {
        getDevice: async () => device,
        getCase: async (authorization, id) => {
          requestedHospitalIds.push(authorization.sourceHospitalRecordId);
          requestedCaseIds.push(id);
          return id === item.sourceRecordId ? item : null;
        },
      },
    );
    const token = signPortalGrantToken(grant, secret);
    const deviceResponse = await fetch(`${baseUrl}/p/${token}/data/devices/device-H1`);
    const payload = await deviceResponse.json() as PortalDeviceDetail;
    const publicCaseId = payload.cases.items[0]!.sourceRecordId;
    const caseResponse = await fetch(`${baseUrl}/p/${token}/data/cases/${publicCaseId}`);

    expect(deviceResponse.status).toBe(200);
    expect(publicCaseId).toBe("history-repair");
    expect(caseResponse.status).toBe(200);
    expect(requestedCaseIds).toEqual(["history-repair"]);
    expect(requestedHospitalIds).toEqual(["hospital-H1"]);
  });

  it("returns controlled 404 and safe CASE_DETAIL log for an invalid Case ID", async () => {
    const grant = portalRecord();
    const log = vi.spyOn(console, "error").mockImplementation(() => undefined);
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(),
      { getCase: async () => null },
    );
    const token = signPortalGrantToken(grant, secret);
    const response = await fetch(`${baseUrl}/p/${token}/data/cases/not-a-case`);

    expect(response.status).toBe(404);
    expect(await response.json()).toEqual({ error: "NOT_FOUND" });
    expect(log).toHaveBeenCalledWith(
      "PORTAL_DATA_REQUEST_FAILED endpoint=CASE_DETAIL hasCaseId=true errorCode=NOT_FOUND status=404",
    );
    expect(log.mock.calls.flat().join(" ")).not.toContain(token);
    log.mockRestore();
  });

  it("passes the returned cursor with the same filter and search to page two", async () => {
    const grant = portalRecord({ sourceHospitalRecordId: "hospital-A" });
    const cursor = encodePortalCaseCursor({
      sortKey: 1_723_546_800_123n, type: "REPAIR", sourceRecordId: "repair-29",
    });
    const requests: Array<{ filter?: string; query?: string; cursor?: string }> = [];
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(),
      {
        listCases: async (_authorization, options) => {
          requests.push(options);
          return { items: [], nextCursor: options.cursor ? null : cursor };
        },
      },
    );
    const token = signPortalGrantToken(grant, secret);
    const first = await fetch(`${baseUrl}/p/${token}/data/cases?filter=REPAIR&q=pompa`);
    expect((await first.json()).nextCursor).toBe(cursor);
    const secondUrl = new URL(`${baseUrl}/p/${token}/data/cases`);
    secondUrl.searchParams.set("filter", "REPAIR");
    secondUrl.searchParams.set("q", "pompa");
    secondUrl.searchParams.set("cursor", cursor);
    expect((await fetch(secondUrl)).status).toBe(200);
    expect(requests).toEqual([
      { filter: "REPAIR", query: "pompa", cursor: undefined, limit: undefined },
      { filter: "REPAIR", query: "pompa", cursor, limit: undefined },
    ]);
  });

  it("returns controlled 400 and a safe log for an invalid cursor", async () => {
    const grant = portalRecord();
    const log = vi.spyOn(console, "error").mockImplementation(() => undefined);
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(),
      { listCases: async (_authorization, options) => {
        decodePortalCaseCursor(options.cursor ?? null);
        return { items: [], nextCursor: null };
      } },
    );
    const token = signPortalGrantToken(grant, secret);
    const response = await fetch(`${baseUrl}/p/${token}/data/cases?filter=REPAIR&q=Pompa&cursor=secret-cursor`);
    expect(response.status).toBe(400);
    expect(await response.json()).toEqual({ error: "INVALID_CURSOR" });
    expect(log).toHaveBeenCalledWith(
      "PORTAL_DATA_REQUEST_FAILED endpoint=cases filter=REPAIR hasCursor=true hasQuery=true errorCode=INVALID_CURSOR status=400",
    );
    expect(log.mock.calls.flat().join(" ")).not.toContain(token);
    expect(log.mock.calls.flat().join(" ")).not.toContain("secret-cursor");
    log.mockRestore();
  });

  it("returns 500 with a safe error code for an unexpected data query failure", async () => {
    const grant = portalRecord();
    const log = vi.spyOn(console, "error").mockImplementation(() => undefined);
    const { baseUrl } = await startApp(
      new MemoryStore(null), grant, new MemoryUnsubscribeStore(null),
      async () => emptyPortalView(),
      { listCases: async () => { throw new Error("Prisma raw query failed"); } },
    );
    const token = signPortalGrantToken(grant, secret);
    const response = await fetch(`${baseUrl}/p/${token}/data/cases?cursor=opaque`);
    expect(response.status).toBe(500);
    expect(await response.json()).toEqual({ error: "INTERNAL_ERROR" });
    expect(log).toHaveBeenCalledWith(
      "PORTAL_DATA_REQUEST_FAILED endpoint=cases filter=ALL hasCursor=true hasQuery=false errorCode=INTERNAL_ERROR status=500",
    );
    log.mockRestore();
  });

  it("GET unsubscribe only displays confirmation and POST records opt-out", async () => {
    const record = unsubscribeRecord();
    const unsubscribeStore = new MemoryUnsubscribeStore(record);
    const { baseUrl } = await startApp(new MemoryStore(null), null, unsubscribeStore);
    const token = signUnsubscribeToken(record, secret);
    const get = await fetch(`${baseUrl}/u/${token}`);
    expect(get.status).toBe(200);
    expect(unsubscribeStore.optOuts).toHaveLength(0);
    const post = await fetch(`${baseUrl}/u/${token}`, { method: "POST" });
    expect(post.status).toBe(200);
    expect(unsubscribeStore.optOuts).toEqual([["recHospital", "client@example.com"]]);
  });
});

class MemoryStore implements PublicAccessLinkStore {
  constructor(private readonly record: PublicAccessLinkRecord | null) {}

  async findByPublicId(publicId: string): Promise<PublicAccessLinkRecord | null> {
    return this.record?.publicId === publicId ? this.record : null;
  }

  async recordValidOpen(): Promise<boolean> { return true; }
}

class MemoryPortalStore implements PublicPortalAccessStore {
  constructor(private readonly record: PublicPortalAccessGrant | null) {}
  async findByPublicId(publicId: string) {
    return this.record?.publicId === publicId ? this.record : null;
  }
  async recordValidOpen(): Promise<boolean> { return true; }
}

class MemoryUnsubscribeStore implements PublicUnsubscribeStore {
  optOuts: Array<[string, string]> = [];
  constructor(private readonly record: UnsubscribeTokenPayload | null) {}
  async findByPublicId(id: string) { return this.record?.publicId === id ? this.record : null; }
  async optOut(hospital: string, email: string) { this.optOuts.push([hospital, email]); }
}

async function startApp(
  store: PublicAccessLinkStore,
  portalGrant: PublicPortalAccessGrant | null = null,
  unsubscribeStore: PublicUnsubscribeStore = new MemoryUnsubscribeStore(null),
  buildPortal: (authorization: PortalAuthorizationContext) => Promise<HospitalPortalViewModel> =
    async () => emptyPortalView(),
  dataViews: {
    listCases?: (
      authorization: PortalAuthorizationContext,
      options: { filter?: string; query?: string; cursor?: string; limit?: number },
    ) => Promise<{ items: []; nextCursor: string | null }>;
    getCase?: (
      authorization: PortalAuthorizationContext,
      id: string,
    ) => Promise<PortalCaseListItem | null>;
    getDevice?: (
      authorization: PortalAuthorizationContext,
      id: string,
    ) => Promise<PortalDeviceDetail | null>;
    listDocuments?: (
      authorization: PortalAuthorizationContext,
      options: { query?: string },
    ) => Promise<{ items: PortalDocument[]; nextCursor: null }>;
    publicFiles?: PublicFileService;
    analytics?: PortalAnalyticsWriter;
    analyticsAdmin?: {
      summary: (...args: any[]) => Promise<unknown>; hospitals: (...args: any[]) => Promise<unknown>;
      hospital: (...args: any[]) => Promise<unknown>; deliveries: (...args: any[]) => Promise<unknown>;
      activity: (...args: any[]) => Promise<unknown>;
    };
    analyticsAuth?: { enabled: boolean; user: string | null; password: string | null };
  } = {},
): Promise<{ baseUrl: string }> {
  const prisma = {
    $queryRaw: async () => [{ ok: 1 }],
  } as unknown as PrismaClient;
  const app = createApp(
    prisma,
    new PublicAccessLinkService(store, secret),
    new PublicPortalAccessService(new MemoryPortalStore(portalGrant), secret),
    new PublicUnsubscribeService(unsubscribeStore, secret),
    { portalViews: {
      build: buildPortal,
      listCases: dataViews.listCases ?? (async () => ({ items: [], nextCursor: null })),
      getCase: dataViews.getCase ?? (async () => null),
      listDevices: async () => ({ items: [], nextCursor: null }),
      getDevice: dataViews.getDevice ?? (async () => null),
      listDocuments: dataViews.listDocuments ?? (async () => ({ items: [], nextCursor: null })),
    }, ...(dataViews.publicFiles ? { publicFiles: dataViews.publicFiles } : {}),
      ...(dataViews.analytics ? { analytics: dataViews.analytics } : {}),
      ...(dataViews.analyticsAdmin ? { analyticsAdmin: dataViews.analyticsAdmin } : {}),
      ...(dataViews.analyticsAuth ? { analyticsAuth: dataViews.analyticsAuth } : {}) },
  );
  server = app.listen(0, "127.0.0.1");
  await new Promise<void>((resolve) => server?.once("listening", resolve));
  const address = server.address() as AddressInfo;
  return { baseUrl: `http://127.0.0.1:${address.port}` };
}

class MemoryAnalytics implements PortalAnalyticsWriter {
  linkClicks: PortalAuthorizationContext[] = [];
  events: Array<{ authorization: PortalAuthorizationContext; input: PortalAnalyticsInput }> = [];
  async recordLinkClick(authorization: PortalAuthorizationContext) { this.linkClicks.push(authorization); }
  async recordPortalEvent(authorization: PortalAuthorizationContext, input: PortalAnalyticsInput) {
    this.events.push({ authorization, input });
  }
}

function portalCase(sourceRecordId: string, caseNumber: string): PortalCaseListItem {
  return {
    type: "REPAIR", sourceRecordId, deviceId: "device-H1", devices: [],
    deviceName: "Device", manufacturer: null, model: null,
    manufacturerModel: null, serialNumber: null, inventoryNumber: null,
    caseNumber, clientOrderNumber: null, currentStatus: "Diagnostyka",
    lastChangedAt: null, requiresAction: false, reportedAt: null,
    inspectionPerformedAt: null, validUntil: null, description: null,
    history: [], documents: [], photos: [],
  };
}

function emptyPortalView(): HospitalPortalViewModel {
  return {
    hospital: { shortName: "Szpital", name: "Szpital", address: null },
    serviceProviderName: "Tiemed",
    summary: { requiresAction: 0, repairs: 0, inspections: 0, devices: 0 },
    accessLevel: "COMMUNICATION",
    teaser: {
      totalDevices: 0, visibleDevices: 0, lockedDevices: 0,
      totalRepairs: 0, visibleRepairs: 0, lockedRepairs: 0,
      totalInspections: 0, visibleInspections: 0, lockedInspections: 0,
    },
    upgradeUrl: "mailto:serwis@tiemed.pl",
    initialCases: { items: [], nextCursor: null },
    focusedCase: null,
  };
}

function unsubscribeRecord(): UnsubscribeTokenPayload {
  return {
    publicId: "unsubscribepublicid00001", communicationDeliveryId: "deliveryId",
    sourceHospitalRecordId: "recHospital", normalizedEmail: "client@example.com",
    canOptOut: true, expiresAt: new Date(Date.now() + 60_000),
  };
}

function portalRecord(
  overrides: Partial<PublicPortalAccessGrant> = {},
): PublicPortalAccessGrant {
  return {
    id: "portalGrantId",
    publicId: "portalpublicid0000000001",
    communicationDeliveryId: "deliveryId",
    sourceHospitalRecordId: "recHospital",
    entryContext: {
      type: "SERVICE_ORDER",
      sourceRecordId: "recService",
      scenario: CommunicationScenario.REPAIR_RECEIVED,
    },
    expiresAt: new Date(Date.now() + 60_000),
    revokedAt: null,
    ...overrides,
  };
}

function accessRecord(): PublicAccessLinkRecord {
  return {
    id: "link-id",
    publicId: "abcdefghijklmnopqrstuvwx",
    digestId: "digest-id",
    expiresAt: new Date(Date.now() + 60_000),
    revokedAt: null,
    digest: {
      items: [{
        trackedCase: {
          caseType: "SERVICE_ORDER",
          businessNumber: "20905",
          deviceName: "Aparat USG",
          manufacturer: null,
          model: null,
          serialNumber: null,
          inventoryNumber: null,
          currentStatus: "Naprawa zakończona",
          faultDescription: null,
          inspectionDueDate: null,
          inspectionScheduledDate: null,
          inspectionBookingStatus: null,
          events: [],
        },
      }],
    },
  };
}
